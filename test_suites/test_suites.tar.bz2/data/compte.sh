#!/bin/bash

# Nom du fichier
fichier="vlm.txt"

# Initialiser le compteur
compteur=0
# Variable pour vérifier la première occurrence
premiere_occurrence=true
# Variable pour stocker la borne précédente
borne_precedente=""

# Lire le fichier ligne par ligne
while IFS= read -r line; do
    # Vérifier si la ligne contient "0$$FILEM VLM DSNIN="
    if [[ $line == "0\$\$FILEM VLM DSNIN="* ]]; then
        # Si ce n'est pas la première occurrence, afficher la borne précédente et le compteur
        if [[ $premiere_occurrence == false ]]; then
            echo "$borne_precedente"
            echo "Nombre de lignes 'Load Module Information' avant la ligne '$line': $compteur"
            # Réinitialiser le compteur pour la prochaine section
            compteur=0
        else
            # Indiquer que la première occurrence est passée
            premiere_occurrence=false
        fi
        # Enregistrer la borne actuelle
        borne_precedente="$line"
    fi
    # Vérifier si la ligne contient "Load Module Information"
    if [[ $line =~ [[:space:]]*Load[[:space:]]+Module[[:space:]]+Information[[:space:]]* ]]; then
        # Incrémenter le compteur
        ((compteur++))
    fi
done < "$fichier"

# Afficher la dernière borne et le compteur pour la dernière section
echo "$borne_precedente"
echo "Nombre de lignes 'Load Module Information' pour la dernière section: $compteur"
